import React, { useState } from 'react';
import { Settings as SettingsIcon, Bell, Key, Wallet, Webhook, Save, Plus, Trash2, LogOut, Shield, Crown, Zap, Check, Loader2, Eye, EyeOff, AlertTriangle } from 'lucide-react';
import { useAppContext } from '../context/AppContext';

const Settings: React.FC = () => {
  const { 
    walletAddress, 
    disconnectWallet, 
    connectWallet,
    apiKeys, 
    generateApiKey, 
    revokeApiKey,
    userTier,
    upgradeTier
  } = useAppContext();

  const [isUpgrading, setIsUpgrading] = useState(false);
  const [visibleKeys, setVisibleKeys] = useState<Record<string, boolean>>({});
  const [showDisconnectModal, setShowDisconnectModal] = useState(false);

  // Handler wrappers to ensure event propagation
  const handleDisconnectRequest = () => {
    setShowDisconnectModal(true);
  };

  const confirmDisconnect = () => {
    disconnectWallet();
    setShowDisconnectModal(false);
  };

  const handleGenerateKey = () => {
    if (userTier === 'FREE') return;
    generateApiKey();
  };

  const toggleKeyVisibility = (id: string) => {
    setVisibleKeys(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleUpgrade = async () => {
    if (isUpgrading) return;
    setIsUpgrading(true);
    try {
      await upgradeTier();
    } catch (e: any) {
      alert(e.message || "Upgrade failed. Please try again.");
    } finally {
      setIsUpgrading(false);
    }
  };

  return (
    <div className="animate-fade-in max-w-4xl mx-auto space-y-8 pb-10">
      <div className="mb-8 border-b-2 border-gray-800 pb-6">
        <h2 className="text-4xl font-bold text-white flex items-center gap-3 uppercase tracking-wide">
          <SettingsIcon className="w-10 h-10 text-gray-500" />
          System Configuration
        </h2>
        <p className="text-gray-400 mt-2 font-mono text-lg">Manage audit parameters, alerts, and access keys.</p>
      </div>

      {/* Subscription Tier */}
      <section className="bg-black border-2 border-gray-700 p-8">
        <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-2 uppercase tracking-wide">
          <Crown className={`w-6 h-6 ${userTier === 'PREMIUM' ? 'text-yellow-500' : 'text-gray-500'}`} />
          Subscription Tier
        </h3>
        
        <div className={`border-2 p-6 flex flex-col md:flex-row items-center justify-between gap-6 ${userTier === 'PREMIUM' ? 'border-yellow-600 bg-yellow-900/10' : 'border-gray-700 bg-gray-900'}`}>
          <div>
            <div className="flex items-center gap-4 mb-2">
              <span className={`text-2xl font-bold uppercase ${userTier === 'PREMIUM' ? 'text-yellow-500' : 'text-white'}`}>
                {userTier === 'PREMIUM' ? 'Premium Plan' : 'Free Plan'}
              </span>
              {userTier === 'PREMIUM' && (
                <span className="px-3 py-1 bg-yellow-500 text-black text-xs font-bold uppercase">ACTIVE</span>
              )}
            </div>
            <p className="text-gray-400 font-mono text-lg">
              {userTier === 'PREMIUM' 
                ? '>> UNLIMITED AUDITS + AI AGENTS + API ACCESS ENABLED.' 
                : '>> LIMITED ACCESS: MINI-APPS ONLY. MAX 2 MONITORS.'}
            </p>
          </div>
          
          {userTier === 'FREE' && (
             <button 
                onClick={handleUpgrade}
                disabled={isUpgrading}
                className="whitespace-nowrap flex items-center gap-2 bg-yellow-500 text-black border-2 border-yellow-700 px-6 py-3 font-bold hover:bg-yellow-400 transition-all shadow-[4px_4px_0px_0px_#000] active:translate-y-1 active:shadow-none uppercase disabled:opacity-50"
             >
               {isUpgrading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Zap className="w-5 h-5 fill-current" />}
               {isUpgrading ? 'Processing...' : 'UPGRADE ($9.99)'}
             </button>
          )}
        </div>
      </section>

      {/* Notifications Section */}
      <section className="bg-black border-2 border-gray-700 p-8">
        <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-2 uppercase tracking-wide">
          <Bell className="w-6 h-6 text-base-blue" />
          Alert Channels
        </h3>
        <div className="space-y-6">
          <div className="flex items-center justify-between p-4 bg-gray-900 border-2 border-gray-700">
            <div>
              <div className="font-bold text-white text-lg uppercase">Email Reports</div>
              <div className="text-sm text-gray-500 font-mono">Send audit summaries to registered email.</div>
            </div>
            {/* Square Toggle */}
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-14 h-8 bg-gray-800 peer-focus:outline-none border-2 border-gray-600 peer-checked:bg-base-blue peer-checked:border-base-blue transition-colors"></div>
              <div className="absolute left-1 top-1 bg-white w-6 h-6 transition-transform peer-checked:translate-x-6"></div>
            </label>
          </div>
          
          <div className="space-y-3">
            <label className="text-sm text-base-blue font-bold uppercase tracking-widest">Webhook Endpoint</label>
            <div className="flex gap-4">
              <div className="relative flex-1">
                <Webhook className="absolute left-4 top-4 w-5 h-5 text-gray-500" />
                <input 
                  type="text" 
                  placeholder="https://your-slack-webhook.com" 
                  className="w-full bg-black border-2 border-gray-700 py-3 pl-12 pr-4 text-white focus:border-base-blue text-lg font-mono"
                />
              </div>
              <button className="px-6 py-3 bg-gray-800 text-white border-2 border-gray-600 hover:bg-gray-700 font-bold uppercase text-sm">Test</button>
            </div>
            <p className="text-xs text-gray-500 font-mono">POST request sent on audit_complete event.</p>
          </div>
        </div>
      </section>

      {/* API Keys */}
      <section className="bg-black border-2 border-gray-700 p-8 relative">
        {userTier === 'FREE' && (
            <div className="absolute inset-0 bg-black/90 z-10 flex flex-col items-center justify-center text-center px-4">
                <div className="p-4 bg-gray-800 border-2 border-gray-600 mb-4">
                  <Crown className="w-8 h-8 text-yellow-500" />
                </div>
                <h4 className="text-2xl font-bold text-white mb-2 uppercase">Developer Access Restricted</h4>
                <p className="text-gray-400 mb-6 max-w-sm font-mono">CI/CD Pipeline Integration requires Premium.</p>
                <button 
                    onClick={handleUpgrade}
                    disabled={isUpgrading}
                    className="bg-white text-black font-bold px-8 py-3 hover:bg-gray-200 transition-colors flex items-center gap-2 disabled:opacity-75 uppercase border-b-4 border-gray-400 active:border-b-0 active:translate-y-1"
                >
                    {isUpgrading && <Loader2 className="w-4 h-4 animate-spin" />}
                    {isUpgrading ? 'Processing...' : 'UNLOCK API ($9.99)'}
                </button>
            </div>
        )}
        <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-2 uppercase tracking-wide">
          <Key className="w-6 h-6 text-yellow-500" />
          API Credentials
        </h3>
        <div className="space-y-4 mb-6">
          {apiKeys.length === 0 ? (
            <p className="text-gray-500 italic p-6 bg-gray-900 border-2 border-dashed border-gray-700 text-center font-mono">NO ACTIVE KEYS FOUND.</p>
          ) : (
            apiKeys.map((key) => (
              <div key={key.id} className="p-4 bg-gray-900 border-2 border-gray-700 flex justify-between items-center group">
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <div className="text-lg font-mono text-white tracking-widest">
                      {visibleKeys[key.id] ? key.key : 'pk_live_' + '•'.repeat(24)}
                    </div>
                    <button 
                      onClick={() => toggleKeyVisibility(key.id)}
                      className="text-gray-500 hover:text-white transition-colors"
                      title={visibleKeys[key.id] ? "Hide Key" : "Show Key"}
                    >
                      {visibleKeys[key.id] ? <EyeOff className="w-4 h-4"/> : <Eye className="w-4 h-4"/>}
                    </button>
                  </div>
                  <div className="text-xs text-gray-500 font-mono uppercase">Created: {key.created} | Last used: {key.lastUsed}</div>
                </div>
                <button 
                  onClick={() => revokeApiKey(key.id)}
                  className="text-xs text-red-500 hover:text-white bg-red-900/20 hover:bg-red-600 border-2 border-red-500/50 hover:border-red-500 px-4 py-2 transition-all flex items-center gap-2 uppercase font-bold"
                >
                  <Trash2 className="w-4 h-4" /> Revoke
                </button>
              </div>
            ))
          )}
        </div>
        <button 
          onClick={handleGenerateKey}
          disabled={userTier === 'FREE'}
          className="w-full py-3 border-2 border-dashed border-gray-600 text-gray-400 hover:text-white hover:border-gray-400 hover:bg-gray-900 transition-colors text-lg font-bold flex items-center justify-center gap-2 disabled:opacity-50 uppercase"
        >
          <Plus className="w-5 h-5" /> Generate New Key
        </button>
      </section>

      {/* Connected Wallet */}
      <section className="bg-black border-2 border-gray-700 p-8">
        <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-2 uppercase tracking-wide">
          <Wallet className="w-6 h-6 text-green-500" />
          Active Wallet
        </h3>
        <div className="flex items-center justify-between p-6 bg-gray-900 border-2 border-gray-700">
           <div className="flex items-center gap-4">
              <div className={`w-12 h-12 flex items-center justify-center border-2 ${walletAddress ? 'bg-blue-900/20 border-base-blue' : 'bg-gray-800 border-gray-600'}`}>
                 <Shield className={`w-6 h-6 ${walletAddress ? 'text-base-blue' : 'text-gray-500'}`} />
              </div>
              <div>
                 {walletAddress ? (
                   <>
                     <div className="text-white font-mono text-xl">{walletAddress}</div>
                     <div className="text-sm text-green-500 flex items-center gap-2 font-bold uppercase mt-1">
                        <div className="w-2 h-2 bg-green-500 animate-pulse"></div>
                        Base Mainnet Connected
                     </div>
                   </>
                 ) : (
                    <>
                      <div className="text-gray-300 font-bold uppercase text-lg">No wallet connected</div>
                      <div className="text-sm text-gray-500 font-mono">Connect to manage payments</div>
                    </>
                 )}
              </div>
           </div>
           
           {walletAddress ? (
             <button 
                onClick={handleDisconnectRequest}
                className="text-sm text-red-400 hover:text-white bg-red-900/20 hover:bg-red-600 px-6 py-2 border-2 border-red-500/50 hover:border-red-500 transition-all flex items-center gap-2 uppercase font-bold"
             >
                <LogOut className="w-4 h-4" /> Disconnect
             </button>
           ) : (
             <button 
                onClick={() => connectWallet()}
                className="text-sm bg-base-blue text-white hover:bg-blue-600 px-6 py-2 border-2 border-base-blue font-bold transition-colors shadow-[0_0_15px_rgba(0,82,255,0.3)] uppercase"
             >
                Connect Wallet
             </button>
           )}
        </div>
      </section>

      <div className="flex justify-end pt-4">
        <button className="flex items-center gap-2 bg-base-blue hover:bg-blue-600 text-white px-8 py-3 border-2 border-white font-bold transition-colors shadow-pixel-blue uppercase text-lg">
          <Save className="w-5 h-5" />
          Save Configuration
        </button>
      </div>

      {/* Disconnect Confirmation Modal */}
      {showDisconnectModal && (
        <div 
            className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in"
            role="dialog"
            aria-modal="true"
            aria-labelledby="disconnect-modal-title"
        >
            <div className="bg-black border-4 border-white max-w-sm w-full p-8 text-center shadow-pixel">
                <div className="bg-red-500/10 w-20 h-20 flex items-center justify-center mx-auto mb-6 border-2 border-red-500">
                  <AlertTriangle className="w-10 h-10 text-red-500" />
                </div>
                <h3 id="disconnect-modal-title" className="text-2xl font-bold text-white mb-2 uppercase">Terminate Session?</h3>
                <p className="text-gray-400 mb-8 font-mono text-lg">Audit history and payment features will be inaccessible.</p>
                <div className="flex gap-4">
                    <button 
                      onClick={() => setShowDisconnectModal(false)} 
                      className="flex-1 py-3 bg-gray-800 hover:bg-gray-700 text-white font-bold transition-colors border-2 border-gray-600 uppercase"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={confirmDisconnect} 
                      className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white font-bold transition-colors border-2 border-red-500 uppercase shadow-lg shadow-red-900/20"
                    >
                      Disconnect
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default Settings;