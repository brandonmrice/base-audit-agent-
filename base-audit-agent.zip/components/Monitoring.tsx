import React, { useState } from 'react';
import { Activity, Clock, CheckCircle, AlertTriangle, Plus, X, Sparkles, Loader2, Lock, Crown } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { analyzeMonitors } from '../services/geminiService';

const Monitoring: React.FC = () => {
  const { monitors, addMonitor, userTier, upgradeTier } = useAppContext();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isUpgrading, setIsUpgrading] = useState(false);
  
  // Form State
  const [name, setName] = useState('');
  const [type, setType] = useState('Mini-App');
  const [endpoint, setEndpoint] = useState('');

  const FREE_TIER_LIMIT = 2;
  const isLimitReached = userTier === 'FREE' && monitors.length >= FREE_TIER_LIMIT;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && endpoint.trim()) {
      addMonitor({
        name,
        type,
        endpoint,
      });
      setName('');
      setType('Mini-App');
      setEndpoint('');
      setIsModalOpen(false);
    }
  };

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    setAnalysis(null);
    const result = await analyzeMonitors(monitors);
    setAnalysis(result);
    setIsAnalyzing(false);
  };

  const handleOpenModal = () => {
    if (isLimitReached) return; 
    setIsModalOpen(true);
  }

  const handleUpgrade = async () => {
    if (isUpgrading) return;
    setIsUpgrading(true);
    try {
        await upgradeTier();
    } catch (e: any) {
        alert(e.message || "Upgrade failed.");
    } finally {
        setIsUpgrading(false);
    }
  }

  return (
    <div className="animate-fade-in space-y-8 relative">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b-2 border-gray-800 pb-6">
        <div>
          <h2 className="text-4xl font-bold text-white flex items-center gap-3 uppercase tracking-wide">
            <Activity className="w-8 h-8 text-green-500" />
            Active Nodes
          </h2>
          <p className="text-gray-400 mt-1 font-mono text-lg">Real-time telemetry for Base ecosystem applications.</p>
        </div>
        <div className="flex gap-4">
          <button 
            onClick={handleAnalyze}
            disabled={isAnalyzing || monitors.length === 0}
            className="bg-purple-900/20 text-purple-400 border-2 border-purple-500 hover:bg-purple-500 hover:text-black px-6 py-2 font-bold transition-all flex items-center gap-2 disabled:opacity-50 uppercase text-sm"
          >
            {isAnalyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            AI Analysis
          </button>
          
          {isLimitReached ? (
              <button 
                onClick={handleUpgrade}
                disabled={isUpgrading}
                className="bg-gray-800 text-gray-400 border-2 border-gray-600 hover:border-gray-500 px-6 py-2 font-bold transition-all flex items-center gap-2 disabled:opacity-75 uppercase text-sm"
              >
                {isUpgrading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
                {isUpgrading ? 'Upgrading...' : 'Limit Reached'}
              </button>
          ) : (
            <button 
                onClick={handleOpenModal}
                className="bg-base-blue text-white border-2 border-blue-400 hover:bg-blue-600 px-6 py-2 font-bold transition-all flex items-center gap-2 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] active:translate-y-1 active:shadow-none uppercase text-sm"
            >
                <Plus className="w-4 h-4" /> Add Node
            </button>
          )}
        </div>
      </div>

      {userTier === 'FREE' && (
        <div className="bg-gray-900 border-2 border-dashed border-gray-700 p-4 flex items-center justify-between">
            <div className="text-lg font-mono">
                <span className="text-yellow-500 font-bold uppercase">Free Tier: </span>
                <span className="text-gray-400">{monitors.length} / {FREE_TIER_LIMIT} nodes active.</span>
            </div>
            <button onClick={handleUpgrade} disabled={isUpgrading} className="text-sm bg-yellow-600 text-black px-4 py-1 font-bold hover:bg-yellow-500 flex items-center gap-2 uppercase">
                {isUpgrading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Crown className="w-3 h-3" />}
                Upgrade
            </button>
        </div>
      )}

      {analysis && (
        <div className="bg-[#1a0b1e] border-2 border-purple-500 p-6 animate-fade-in mb-8 shadow-pixel">
           <h3 className="text-purple-400 font-bold mb-3 flex items-center gap-2 uppercase tracking-wider">
             <Sparkles className="w-4 h-4" /> Gemini Telemetry Insight
           </h3>
           <p className="text-gray-200 text-lg leading-relaxed font-mono">{analysis}</p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-black border-2 border-gray-700 p-6 relative">
          <div className="absolute top-2 right-2 w-2 h-2 bg-green-500 animate-pulse"></div>
          <div className="text-gray-500 text-xs uppercase font-bold mb-2">Total Monitored</div>
          <div className="text-5xl font-bold text-white">{monitors.length}</div>
          <div className="text-sm text-green-500 mt-2 font-mono">>> running</div>
        </div>
        <div className="bg-black border-2 border-gray-700 p-6">
          <div className="text-gray-500 text-xs uppercase font-bold mb-2">Global Uptime</div>
          <div className="text-5xl font-bold text-white">99.9%</div>
          <div className="text-sm text-gray-500 mt-2 font-mono">Last 30 days</div>
        </div>
        <div className="bg-black border-2 border-gray-700 p-6">
          <div className="text-gray-500 text-xs uppercase font-bold mb-2">Incidents</div>
          <div className="text-5xl font-bold text-white">0</div>
          <div className="text-sm text-gray-500 mt-2 font-mono">Last 24h</div>
        </div>
      </div>

      <div className="border-2 border-gray-700 bg-black">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-lg text-gray-400 font-mono">
            <thead className="bg-gray-900 text-sm uppercase font-bold border-b-2 border-gray-700 text-gray-500">
              <tr>
                <th className="px-6 py-4">Service Name</th>
                <th className="px-6 py-4">Type</th>
                <th className="px-6 py-4">Endpoint</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Uptime</th>
                <th className="px-6 py-4">Last Check</th>
              </tr>
            </thead>
            <tbody className="divide-y-2 divide-gray-800">
              {monitors.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-16 text-center text-gray-500 bg-gray-900/20 italic">
                    NO ACTIVE NODES. SYSTEM IDLE.
                  </td>
                </tr>
              ) : (
                monitors.map((m) => (
                  <tr key={m.id} className="hover:bg-gray-900 transition-colors group">
                    <td className="px-6 py-4 font-bold text-white flex items-center gap-3">
                      <div className={`w-3 h-3 ${m.status === 'Healthy' ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                      {m.name}
                    </td>
                    <td className="px-6 py-4">
                      <span className="bg-gray-800 text-gray-300 px-3 py-1 border border-gray-600 text-sm uppercase font-bold">
                        {m.type}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600 group-hover:text-base-blue transition-colors">
                      {m.endpoint}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-2 px-3 py-1 text-sm font-bold border-2 ${
                        m.status === 'Healthy' 
                          ? 'bg-green-900/20 text-green-500 border-green-500' 
                          : 'bg-yellow-900/20 text-yellow-500 border-yellow-500'
                      }`}>
                        {m.status === 'Healthy' ? <CheckCircle className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
                        {m.status.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-6 py-4">{m.uptime}</td>
                    <td className="px-6 py-4 flex items-center gap-2 text-gray-500 text-sm">
                      <Clock className="w-4 h-4" />
                      {m.lastCheck}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Monitor Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4 animate-fade-in">
           <div className="bg-black border-4 border-gray-700 w-full max-w-lg shadow-pixel">
              <div className="flex justify-between items-center p-6 border-b-2 border-gray-700 bg-gray-900">
                 <h3 className="text-2xl font-bold text-white uppercase tracking-wider">Configure New Node</h3>
                 <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-white border-2 border-transparent hover:border-white p-1">
                    <X className="w-6 h-6" />
                 </button>
              </div>
              <form onSubmit={handleSubmit} className="p-8 space-y-6">
                 <div className="space-y-2">
                    <label className="text-sm font-bold text-base-blue uppercase">Service Name</label>
                    <input 
                      type="text" 
                      value={name}
                      onChange={e => setName(e.target.value)}
                      placeholder="E.G. PROD_API_01" 
                      className="w-full bg-black border-2 border-gray-700 py-3 px-4 text-white focus:border-base-blue text-lg"
                      required
                    />
                 </div>
                 <div className="space-y-2">
                    <label className="text-sm font-bold text-base-blue uppercase">Node Type</label>
                    <select 
                      value={type}
                      onChange={e => setType(e.target.value)}
                      className="w-full bg-black border-2 border-gray-700 py-3 px-4 text-white focus:border-base-blue text-lg"
                    >
                       <option>Mini-App</option>
                       <option>AI Agent</option>
                       <option>Smart Contract</option>
                    </select>
                 </div>
                 <div className="space-y-2">
                    <label className="text-sm font-bold text-base-blue uppercase">Endpoint / Address</label>
                    <input 
                      type="text" 
                      value={endpoint}
                      onChange={e => setEndpoint(e.target.value)}
                      placeholder="HTTPS://... OR 0X..." 
                      className="w-full bg-black border-2 border-gray-700 py-3 px-4 text-white focus:border-base-blue text-lg"
                      required
                    />
                 </div>
                 <div className="pt-6 flex gap-4">
                    <button 
                      type="button" 
                      onClick={() => setIsModalOpen(false)}
                      className="flex-1 py-3 bg-gray-900 text-gray-300 border-2 border-gray-700 hover:bg-gray-800 font-bold uppercase tracking-wide"
                    >
                      Cancel
                    </button>
                    <button 
                      type="submit"
                      className="flex-1 py-3 bg-base-blue text-white border-2 border-base-blue hover:bg-blue-600 font-bold uppercase tracking-wide shadow-[4px_4px_0px_0px_#000]"
                    >
                      Initialize
                    </button>
                 </div>
              </form>
           </div>
        </div>
      )}
    </div>
  );
};

export default Monitoring;