import React from 'react';
import { AuditResult, Severity } from '../types';
import { ResponsiveContainer, BarChart, Bar, XAxis, Tooltip, Cell } from 'recharts';
import { AlertOctagon, CheckCircle, Download, Share2, ExternalLink, Code } from 'lucide-react';

interface AuditReportProps {
  result: AuditResult;
}

const AuditReport: React.FC<AuditReportProps> = ({ result }) => {
  
  const getSeverityColor = (s: Severity) => {
    switch (s) {
      case Severity.CRITICAL: return 'text-red-500 border-red-500 bg-red-900/10';
      case Severity.HIGH: return 'text-orange-500 border-orange-500 bg-orange-900/10';
      case Severity.MEDIUM: return 'text-yellow-500 border-yellow-500 bg-yellow-900/10';
      case Severity.LOW: return 'text-blue-400 border-blue-400 bg-blue-900/10';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-500';
    if (score >= 70) return 'text-yellow-500';
    return 'text-red-500';
  };

  const chartData = result.categories.map(c => ({
    subject: c.name,
    A: c.score,
    fullMark: 100,
  }));

  const allIssues = result.categories.flatMap(c => c.issues);
  const criticalCount = allIssues.filter(i => i.severity === Severity.CRITICAL).length;
  const highCount = allIssues.filter(i => i.severity === Severity.HIGH).length;

  return (
    <div className="animate-fade-in space-y-8 pb-10">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b-2 border-gray-800 pb-6">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <h2 className="text-4xl font-bold text-white uppercase tracking-wider">Audit Artifact</h2>
            <span className="px-2 py-1 text-sm bg-gray-800 text-gray-400 border border-gray-600 font-mono">
              #{result.id.slice(0, 8)}
            </span>
          </div>
          <p className="text-gray-500 font-mono text-lg">{result.target}</p>
        </div>
        <div className="flex gap-4">
          <button className="flex items-center gap-2 px-6 py-2 bg-black border-2 border-gray-600 text-gray-300 hover:border-white hover:text-white transition-all uppercase font-bold text-sm">
            <Download className="w-4 h-4" /> JSON Export
          </button>
          <button className="flex items-center gap-2 px-6 py-2 bg-base-blue text-white border-2 border-base-blue hover:bg-white hover:text-base-blue transition-all uppercase font-bold text-sm">
            <Share2 className="w-4 h-4" /> Share
          </button>
        </div>
      </div>

      {/* Top Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Overall Score */}
        <div className="bg-black border-2 border-gray-700 p-6 flex flex-col justify-between h-48 relative overflow-hidden">
          <div className={`absolute top-0 right-0 p-2 text-xs border-l-2 border-b-2 border-gray-700 bg-gray-900 ${getScoreColor(result.totalScore)}`}>
            FINAL_SCORE
          </div>
          <h3 className="text-gray-500 text-sm font-bold uppercase tracking-widest">Security Rating</h3>
          <div className={`text-7xl font-bold mt-2 ${getScoreColor(result.totalScore)}`}>
            {result.totalScore}
          </div>
          <div className="w-full bg-gray-800 h-4 mt-4 border border-gray-600">
             <div className={`h-full ${result.totalScore >= 80 ? 'bg-green-500' : 'bg-red-500'}`} style={{width: `${result.totalScore}%`}}></div>
          </div>
        </div>

        {/* Issue Summary */}
        <div className="bg-black border-2 border-gray-700 p-6 h-48">
           <h3 className="text-gray-500 text-sm font-bold uppercase tracking-widest mb-6">Vulnerability Matrix</h3>
           <div className="grid grid-cols-4 gap-2">
              <div className="text-center border border-gray-800 p-2">
                <div className="text-3xl font-bold text-red-500">{criticalCount}</div>
                <div className="text-[10px] uppercase text-gray-500 mt-1">Crit</div>
              </div>
              <div className="text-center border border-gray-800 p-2">
                <div className="text-3xl font-bold text-orange-500">{highCount}</div>
                <div className="text-[10px] uppercase text-gray-500 mt-1">High</div>
              </div>
              <div className="text-center border border-gray-800 p-2">
                <div className="text-3xl font-bold text-yellow-500">{allIssues.filter(i => i.severity === Severity.MEDIUM).length}</div>
                <div className="text-[10px] uppercase text-gray-500 mt-1">Med</div>
              </div>
              <div className="text-center border border-gray-800 p-2">
                <div className="text-3xl font-bold text-blue-400">{allIssues.filter(i => i.severity === Severity.LOW).length}</div>
                <div className="text-[10px] uppercase text-gray-500 mt-1">Low</div>
              </div>
           </div>
        </div>

         {/* Pass Rate */}
         <div className="bg-black border-2 border-gray-700 p-6 h-48">
            <h3 className="text-gray-500 text-sm font-bold uppercase tracking-widest mb-2">Category Breakdown</h3>
             <div className="h-28 w-full -ml-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData}>
                    <XAxis dataKey="subject" tick={{fontSize: 10, fontFamily: 'VT323'}} stroke="#4b5563" />
                    <Tooltip 
                      contentStyle={{backgroundColor: '#000', borderColor: '#333', color: '#fff', fontFamily: 'VT323'}}
                      itemStyle={{color: '#fff'}}
                      cursor={{fill: 'rgba(255, 255, 255, 0.1)'}}
                    />
                    <Bar dataKey="A">
                       {chartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.A > 80 ? '#22c55e' : entry.A > 60 ? '#eab308' : '#ef4444'} />
                        ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
             </div>
        </div>
      </div>

      {/* Main Content Split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Issues List (Left 2/3) */}
        <div className="lg:col-span-2 space-y-6">
           <div className="bg-black border-2 border-gray-700 p-6">
              <h3 className="text-2xl font-bold text-white mb-8 flex items-center gap-3 uppercase border-b-2 border-gray-800 pb-4">
                <AlertOctagon className="w-6 h-6 text-red-500" />
                Remediation Plan
              </h3>
              
              <div className="space-y-6">
                {allIssues.length === 0 ? (
                  <div className="text-center py-16 border-2 border-dashed border-gray-800">
                    <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-500 opacity-50" />
                    <p className="text-xl text-gray-500 uppercase">System Clean. No Threats Detected.</p>
                  </div>
                ) : (
                  allIssues.sort((a,b) => {
                     const order = { [Severity.CRITICAL]: 0, [Severity.HIGH]: 1, [Severity.MEDIUM]: 2, [Severity.LOW]: 3 };
                     return order[a.severity] - order[b.severity];
                  }).map((issue, idx) => (
                    <div key={idx} className="bg-gray-900 border-2 border-gray-800 hover:border-gray-600 transition-colors p-5 group">
                      <div className="flex items-start justify-between mb-3">
                         <div className="flex items-center gap-3">
                            <span className={`px-3 py-1 text-sm font-bold border-2 uppercase ${getSeverityColor(issue.severity)}`}>
                              {issue.severity}
                            </span>
                            {issue.vulnerabilityType && (
                               <span className="text-sm text-gray-400 bg-black px-2 py-1 border border-gray-700 font-mono">
                                 [{issue.vulnerabilityType}]
                               </span>
                            )}
                         </div>
                      </div>
                      <h4 className="text-xl font-bold text-gray-200 mb-2 group-hover:text-white">{issue.title}</h4>
                      <p className="text-gray-400 text-lg mb-4 leading-relaxed">{issue.description}</p>
                      
                      <div className="grid gap-4">
                        <div className="bg-black/50 p-4 border border-gray-700 border-l-4 border-l-base-blue">
                          <div className="text-xs font-bold text-base-blue mb-1 uppercase tracking-widest">Recommended Fix</div>
                          <p className="text-md text-gray-300 font-mono">{issue.remediation}</p>
                        </div>
                        {issue.codeSnippet && (
                          <div className="bg-black p-4 border border-gray-700 font-mono text-sm overflow-x-auto relative">
                             <div className="absolute top-0 right-0 bg-gray-800 text-gray-400 text-[10px] px-2 py-0.5 border-l border-b border-gray-700 uppercase">
                                snippet
                             </div>
                             <div className="flex items-center gap-2 text-gray-500 mb-2">
                                <Code className="w-4 h-4" />
                                <span className="uppercase text-xs font-bold">Reference Code</span>
                             </div>
                             <pre className="text-green-400/90">{issue.codeSnippet}</pre>
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
           </div>
        </div>

        {/* AI Insight (Right 1/3) */}
        <div className="space-y-6">
           <div className="bg-[#050505] border-2 border-base-blue/50 p-6 shadow-pixel-blue">
              <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2 uppercase">
                <span className="text-2xl animate-pulse">🤖</span> AI Analysis
              </h3>
              <div className="text-gray-300 text-lg leading-relaxed space-y-4 font-mono">
                <p>{result.summary}</p>
                <div className="h-0.5 bg-gray-800 my-6"></div>
                <div>
                  <h4 className="font-bold text-white mb-3 uppercase text-sm tracking-widest">Knowledge Base</h4>
                  <ul className="space-y-3 text-sm text-base-blue">
                    <li className="flex items-center gap-2 hover:text-white cursor-pointer transition-colors">
                      <ExternalLink className="w-4 h-4" /> Base Docs: Security
                    </li>
                    <li className="flex items-center gap-2 hover:text-white cursor-pointer transition-colors">
                      <ExternalLink className="w-4 h-4" /> OnchainKit Manual
                    </li>
                     <li className="flex items-center gap-2 hover:text-white cursor-pointer transition-colors">
                      <ExternalLink className="w-4 h-4" /> CDP Documentation
                    </li>
                  </ul>
                </div>
              </div>
           </div>
        </div>

      </div>
    </div>
  );
};

export default AuditReport;