import React from 'react';
import { MOCK_RECENT_AUDITS } from '../constants';
import { Shield, Activity, Bell, Plus, ArrowRight } from 'lucide-react';

interface DashboardProps {
  onNewAudit: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNewAudit }) => {
  return (
    <div className="animate-fade-in space-y-8">
      
      {/* Welcome Hero */}
      <div className="relative bg-[#0052FF] border-2 border-white p-8 text-white shadow-pixel-blue">
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
             <h2 className="text-4xl font-bold mb-2 uppercase tracking-wide">Welcome, Developer</h2>
             <p className="text-blue-100 max-w-xl text-xl">
               System active. 3 monitoring agents operational on Base Mainnet.
             </p>
          </div>
          <button 
            onClick={onNewAudit}
            className="bg-white text-base-blue border-2 border-black px-6 py-3 font-bold hover:bg-gray-100 transition-colors flex items-center gap-2 text-lg shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] active:translate-y-1 active:shadow-none"
          >
            <Plus className="w-5 h-5" /> INITIATE AUDIT
          </button>
        </div>
        {/* Pixel Pattern Background */}
        <div className="absolute inset-0 opacity-10 pointer-events-none" 
             style={{ backgroundImage: 'linear-gradient(45deg, #000 25%, transparent 25%, transparent 75%, #000 75%, #000), linear-gradient(45deg, #000 25%, transparent 25%, transparent 75%, #000 75%, #000)', backgroundSize: '20px 20px', backgroundPosition: '0 0, 10px 10px' }}>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gray-900 border-2 border-gray-700 p-6 hover:border-base-blue transition-colors group">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-blue-900 border-2 border-blue-500 text-blue-400 group-hover:bg-blue-500 group-hover:text-white transition-colors">
              <Shield className="w-8 h-8" />
            </div>
            <div>
              <div className="text-4xl font-bold text-white">24</div>
              <div className="text-sm text-gray-500 uppercase tracking-widest">Total Audits</div>
            </div>
          </div>
        </div>
        <div className="bg-gray-900 border-2 border-gray-700 p-6 hover:border-green-500 transition-colors group">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-green-900 border-2 border-green-500 text-green-400 group-hover:bg-green-500 group-hover:text-white transition-colors">
              <Activity className="w-8 h-8" />
            </div>
            <div>
              <div className="text-4xl font-bold text-white">98.5%</div>
              <div className="text-sm text-gray-500 uppercase tracking-widest">System Health</div>
            </div>
          </div>
        </div>
        <div className="bg-gray-900 border-2 border-gray-700 p-6 hover:border-yellow-500 transition-colors group">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-yellow-900 border-2 border-yellow-500 text-yellow-400 group-hover:bg-yellow-500 group-hover:text-black transition-colors">
              <Bell className="w-8 h-8" />
            </div>
            <div>
              <div className="text-4xl font-bold text-white">2</div>
              <div className="text-sm text-gray-500 uppercase tracking-widest">Active Alerts</div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="border-2 border-gray-700 bg-black">
        <div className="p-4 border-b-2 border-gray-700 flex justify-between items-center bg-gray-900">
          <h3 className="font-bold text-white text-xl uppercase">Recent Logs</h3>
          <button className="text-sm text-base-blue hover:text-white hover:bg-base-blue px-2 py-1 uppercase font-bold border-2 border-transparent hover:border-white transition-all">
            View All logs
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-lg text-gray-400 font-mono">
            <thead className="bg-gray-900 text-sm uppercase text-gray-500 border-b-2 border-gray-700">
              <tr>
                <th className="px-6 py-4">Target</th>
                <th className="px-6 py-4">Score</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Time</th>
                <th className="px-6 py-4">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y-2 divide-gray-800">
              {MOCK_RECENT_AUDITS.map((audit) => (
                <tr key={audit.id} className="hover:bg-gray-900 transition-colors">
                  <td className="px-6 py-4 text-white">{audit.target}</td>
                  <td className="px-6 py-4">
                    <span className={`font-bold ${
                      audit.score >= 80 ? 'text-green-500' : audit.score >= 50 ? 'text-yellow-500' : 'text-red-500'
                    }`}>{audit.score}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 text-sm font-bold border-2 ${
                       audit.status === 'PASS' ? 'border-green-500 text-green-500 bg-green-900/20' :
                       audit.status === 'WARNING' ? 'border-yellow-500 text-yellow-500 bg-yellow-900/20' :
                       'border-red-500 text-red-500 bg-red-900/20'
                    }`}>
                      {audit.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm">{audit.date}</td>
                  <td className="px-6 py-4">
                    <button className="text-base-blue hover:text-white hover:underline flex items-center gap-1">
                        REPORT <ArrowRight className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};

export default Dashboard;