import React, { useState } from 'react';
import { AuditType } from '../types';
import { Search, Code, Cpu, Layers, DollarSign, Wallet, Loader2, AlertTriangle, Lock, Zap } from 'lucide-react';
import { payUSDC } from '../services/paymentService';
import { TREASURY_WALLET } from '../constants';
import { useAppContext } from '../context/AppContext';

interface AuditFormProps {
  onSubmit: (target: string, type: AuditType) => void;
}

const AuditForm: React.FC<AuditFormProps> = ({ onSubmit }) => {
  const { userTier, upgradeTier } = useAppContext();
  const [target, setTarget] = useState('');
  const [type, setType] = useState<AuditType>(AuditType.MINI_APP);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [isUpgrading, setIsUpgrading] = useState(false);
  const [paymentError, setPaymentError] = useState<string | null>(null);

  const getCost = (t: AuditType) => {
    switch(t) {
        case AuditType.MINI_APP: return "0.01";
        case AuditType.AI_AGENT: return "0.05";
        case AuditType.SMART_CONTRACT: return "0.10";
    }
  }

  const isLocked = (t: AuditType) => {
    if (userTier === 'PREMIUM') return false;
    return t === AuditType.AI_AGENT || t === AuditType.SMART_CONTRACT;
  }

  const handleStartAudit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPaymentError(null);
    
    if (!target.trim()) return;

    if (isLocked(type)) {
        setPaymentError("This audit type requires a Premium subscription.");
        return; 
    }

    setIsProcessingPayment(true);
    const cost = getCost(type);

    try {
      await payUSDC(cost);
      onSubmit(target, type);
    } catch (error: any) {
      console.error(error);
      setPaymentError(error.message || "Payment verification failed.");
      setIsProcessingPayment(false);
    }
  };

  const handleUpgrade = async () => {
    if (isUpgrading) return;
    setIsUpgrading(true);
    try {
        await upgradeTier();
    } catch (e: any) {
        setPaymentError(e.message || "Upgrade failed");
    } finally {
        setIsUpgrading(false);
    }
  }

  return (
    <div className="max-w-3xl mx-auto mt-6 animate-fade-in">
      <div className="text-center mb-10 border-b-2 border-gray-800 pb-8">
        <h2 className="text-4xl font-bold text-white mb-3 uppercase tracking-wider">Initialize Audit</h2>
        <p className="text-gray-400 text-xl font-mono">Select target vector for security verification.</p>
      </div>

      <div className="bg-black border-2 border-gray-700 p-8 shadow-pixel relative">
        {(isProcessingPayment || isUpgrading) && (
          <div className="absolute inset-0 bg-black/90 z-20 flex flex-col items-center justify-center text-center p-6 border-2 border-base-blue m-2">
            <Loader2 className="w-16 h-16 text-base-blue animate-spin mb-6" />
            <h3 className="text-2xl font-bold text-white mb-2 uppercase tracking-widest">
                {isUpgrading ? 'UPGRADING ACCOUNT...' : 'PROCESSING TRANSACTION...'}
            </h3>
            <p className="text-gray-400 font-mono">Waiting for wallet confirmation</p>
            {!isUpgrading && (
                <div className="mt-6 p-4 bg-gray-900 border-2 border-gray-700 w-full max-w-sm">
                    <div className="flex items-center justify-between text-sm text-gray-400 mb-2 border-b border-gray-800 pb-2">
                        <span className="uppercase">Amount</span>
                        <span className="text-white font-bold">{getCost(type)} USDC</span>
                    </div>
                    <div className="flex items-center justify-between text-sm text-gray-500">
                        <span className="uppercase">Destination</span>
                        <span className="font-mono text-base-blue">{TREASURY_WALLET.slice(0, 6)}...</span>
                    </div>
                </div>
            )}
          </div>
        )}

        <form onSubmit={handleStartAudit} className="space-y-8">
          
          <div className="space-y-4">
            <label className="text-sm font-bold text-base-blue uppercase tracking-widest">Target Configuration</label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                { id: AuditType.MINI_APP, icon: Layers, label: 'MINI-APP', locked: false },
                { id: AuditType.AI_AGENT, icon: Cpu, label: 'AI AGENT', locked: isLocked(AuditType.AI_AGENT) },
                { id: AuditType.SMART_CONTRACT, icon: Code, label: 'CONTRACT', locked: isLocked(AuditType.SMART_CONTRACT) },
              ].map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => !item.locked && setType(item.id)}
                  disabled={isProcessingPayment || item.locked}
                  className={`relative flex flex-col items-center justify-center gap-3 p-6 border-2 transition-all h-32 ${
                    type === item.id
                      ? 'bg-blue-900/20 border-base-blue text-white shadow-pixel-blue'
                      : item.locked 
                        ? 'bg-gray-900 border-gray-800 text-gray-600 cursor-not-allowed'
                        : 'bg-black border-gray-700 text-gray-400 hover:border-gray-500 hover:bg-gray-900'
                  }`}
                >
                  <item.icon className="w-8 h-8" />
                  <span className="font-bold tracking-wider">{item.label}</span>
                  {item.locked && (
                      <div className="absolute inset-0 bg-black/60 flex items-center justify-center border-2 border-transparent">
                          <div className="bg-gray-800 px-3 py-1 border border-gray-600 flex items-center gap-2">
                             <Lock className="w-3 h-3 text-yellow-500" />
                             <span className="text-xs font-bold text-yellow-500">PRO</span>
                          </div>
                      </div>
                  )}
                  {type === item.id && (
                      <div className="absolute top-2 right-2 w-3 h-3 bg-base-blue shadow-[0_0_10px_#0052FF]"></div>
                  )}
                </button>
              ))}
            </div>
             {isLocked(AuditType.AI_AGENT) && (
                <div className="mt-4 p-4 border-2 border-blue-900 bg-blue-900/10 text-center">
                    <p className="text-sm text-blue-200 mb-3 font-mono">ACCESS RESTRICTED: UPGRADE REQUIRED FOR ADVANCED MODULES</p>
                    <button type="button" onClick={handleUpgrade} className="text-sm bg-base-blue text-white px-6 py-2 hover:bg-blue-600 border-2 border-white transition-colors uppercase font-bold flex items-center justify-center mx-auto gap-2">
                        {isUpgrading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4 fill-current" />}
                        UNLOCK PREMIUM
                    </button>
                </div>
            )}
          </div>

          <div className="space-y-4">
            <label className="text-sm font-bold text-base-blue uppercase tracking-widest">Source Input</label>
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-gray-500">
                <Search className="w-6 h-6 group-focus-within:text-base-blue transition-colors" />
              </div>
              <input
                type="text"
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                placeholder={
                  type === AuditType.SMART_CONTRACT
                    ? "0x..."
                    : type === AuditType.MINI_APP
                    ? "https://github.com/..."
                    : "https://agent-api..."
                }
                className="w-full bg-black border-2 border-gray-700 py-4 pl-12 pr-4 text-white text-lg placeholder-gray-700 font-mono focus:border-base-blue transition-colors disabled:opacity-50"
                required
                disabled={isProcessingPayment}
              />
            </div>
          </div>

          {paymentError && (
            <div className="p-4 bg-red-900/20 border-2 border-red-500 flex items-center gap-3 text-red-400">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <span className="font-bold">{paymentError}</span>
            </div>
          )}

          <div className="pt-6 border-t-2 border-gray-800 flex items-center justify-between">
            <div className="flex flex-col">
                 <span className="text-xs text-gray-500 uppercase tracking-widest mb-1">Estimated Cost</span>
                 <span className="text-3xl font-bold text-white flex items-center font-mono">
                    <DollarSign className="w-6 h-6 text-base-blue" />
                    {getCost(type)}
                 </span>
            </div>
            <button
              type="submit"
              disabled={!target || isProcessingPayment || isLocked(type)}
              className="bg-base-blue hover:bg-blue-600 text-white px-8 py-4 text-lg font-bold flex items-center gap-3 transition-all disabled:opacity-50 disabled:cursor-not-allowed border-b-4 border-blue-800 active:border-b-0 active:translate-y-1"
            >
              <Wallet className="w-5 h-5" />
              EXECUTE PAY & AUDIT
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AuditForm;