import React, { useState } from 'react';
import { LayoutDashboard, ShieldCheck, Activity, Settings, Menu, X, LogIn, Crown, Zap, Loader2 } from 'lucide-react';
import { useAppContext } from '../context/AppContext';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, onTabChange }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const { walletAddress, connectWallet, isConnecting, userTier, upgradeTier } = useAppContext();
  const [isUpgrading, setIsUpgrading] = useState(false);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'audit', label: 'New Audit', icon: ShieldCheck },
    { id: 'monitor', label: 'Monitoring', icon: Activity },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const formatAddress = (addr: string) => {
    return `${addr.slice(0, 4)}...${addr.slice(-4)}`;
  };

  const handleUpgrade = async () => {
    if (isUpgrading) return;
    setIsUpgrading(true);
    try {
      await upgradeTier();
    } catch (e: any) {
      alert(e.message || "Upgrade failed.");
    } finally {
      setIsUpgrading(false);
    }
  };

  return (
    <div className="min-h-screen bg-base-dark text-gray-200 font-sans flex flex-col md:flex-row">
      {/* Sidebar - Desktop */}
      <aside className="hidden md:flex flex-col w-64 border-r-2 border-gray-800 bg-[#0A0A0A] fixed h-full z-10">
        <div className="p-6 border-b-2 border-gray-800 bg-gray-900/50">
          <h1 className="text-2xl font-bold flex items-center gap-2 text-base-blue uppercase tracking-wider">
            <ShieldCheck className="w-6 h-6" />
            <span>Base Audit</span>
            {userTier === 'PREMIUM' && (
              <span className="text-sm bg-yellow-600 text-black px-1.5 font-bold">
                PRO
              </span>
            )}
          </h1>
          <p className="text-sm text-gray-500 mt-1 font-mono">> v1.0.4 initialized</p>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 text-lg font-medium transition-all border-2 ${
                activeTab === item.id
                  ? 'bg-base-blue text-white border-base-blue shadow-pixel-blue'
                  : 'hover:bg-gray-800 text-gray-400 border-transparent hover:border-gray-700'
              }`}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </button>
          ))}
        </nav>
        
        {/* Tier Status Card */}
        <div className="px-4 pb-4">
            <div className={`p-4 border-2 ${userTier === 'PREMIUM' ? 'bg-yellow-900/10 border-yellow-600' : 'bg-gray-900 border-gray-700'}`}>
                <div className="flex items-center justify-between mb-2">
                    <span className={`text-sm font-bold uppercase tracking-wider ${userTier === 'PREMIUM' ? 'text-yellow-500' : 'text-gray-400'}`}>
                        {userTier === 'PREMIUM' ? 'PREMIUM ACCESS' : 'FREE TIER'}
                    </span>
                    {userTier === 'PREMIUM' && <Crown className="w-4 h-4 text-yellow-500" />}
                </div>
                {userTier === 'FREE' ? (
                    <>
                        <p className="text-sm text-gray-500 mb-3 leading-tight">Upgrade to unlock AI agents & contracts.</p>
                        <button 
                            onClick={handleUpgrade}
                            disabled={isUpgrading}
                            className="w-full bg-yellow-500 text-black hover:bg-yellow-400 py-2 text-sm font-bold transition-all flex items-center justify-center gap-2 disabled:opacity-75 border-b-4 border-yellow-700 active:border-b-0 active:translate-y-1"
                        >
                            {isUpgrading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3 fill-current" />}
                            {isUpgrading ? 'PROCESSING...' : 'UPGRADE NOW'}
                        </button>
                    </>
                ) : (
                    <p className="text-sm text-yellow-500/80">Full enterprise access enabled.</p>
                )}
            </div>
        </div>

        <div className="p-4 border-t-2 border-gray-800">
          <div className="bg-gray-900 border-2 border-gray-800 p-3">
            <div className="text-xs text-gray-500 mb-2 uppercase">Wallet Status</div>
            {walletAddress ? (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 animate-pulse"></div>
                  <span className="text-sm font-mono text-gray-300">{formatAddress(walletAddress)}</span>
                </div>
                <span className="text-sm font-bold text-base-blue">342 USDC</span>
              </div>
            ) : (
              <button 
                onClick={connectWallet}
                disabled={isConnecting}
                className="w-full flex items-center justify-center gap-2 bg-gray-800 border-2 border-gray-600 text-white py-2 text-sm font-medium hover:bg-gray-700 hover:border-gray-500 transition-colors disabled:opacity-50"
              >
                {isConnecting ? (
                    <Loader2 className="w-3 h-3 animate-spin" />
                ) : (
                    <LogIn className="w-3 h-3" />
                )}
                {isConnecting ? 'CONNECTING...' : 'CONNECT WALLET'}
              </button>
            )}
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between p-4 border-b-2 border-gray-800 bg-black sticky top-0 z-20">
         <h1 className="text-xl font-bold flex items-center gap-2 text-base-blue uppercase">
            <ShieldCheck className="w-6 h-6" />
            <span>Base Audit</span>
            {userTier === 'PREMIUM' && <span className="text-xs bg-yellow-500 text-black px-1">PRO</span>}
          </h1>
          <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="border-2 border-gray-700 p-1">
            {isMobileMenuOpen ? <X /> : <Menu />}
          </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 bg-black z-10 pt-20 px-4">
           <nav className="space-y-4">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  onTabChange(item.id);
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-4 text-xl font-medium border-2 ${
                  activeTab === item.id
                    ? 'bg-base-blue text-white border-white'
                    : 'border-gray-800 text-gray-400 bg-gray-900'
                }`}
              >
                <item.icon className="w-6 h-6" />
                {item.label}
              </button>
            ))}
          </nav>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 md:ml-64 p-4 md:p-8 overflow-y-auto">
        <div className="max-w-6xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;