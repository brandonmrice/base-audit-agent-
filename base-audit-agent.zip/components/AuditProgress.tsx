import React, { useEffect, useRef, useState } from 'react';
import { AuditType, LogEntry } from '../types';
import { CHECKPOINTS } from '../constants';
import { Terminal, Loader2 } from 'lucide-react';

interface AuditProgressProps {
  target: string;
  type: AuditType;
  onComplete: () => void;
}

const AuditProgress: React.FC<AuditProgressProps> = ({ target, type, onComplete }) => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [progress, setProgress] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    let mounted = true;
    const checkpoints = CHECKPOINTS[type];
    const totalSteps = checkpoints.length + 5;
    let currentStep = 0;

    const addLog = (message: string, type: LogEntry['type'] = 'info') => {
      if (!mounted) return;
      setLogs(prev => [...prev, {
        id: Date.now(),
        message,
        type,
        timestamp: Date.now()
      }]);
    };

    const runSimulation = async () => {
      addLog(`Initializing audit sequence...`);
      addLog(`Target: ${target}`);
      await new Promise(r => setTimeout(r, 800));
      
      addLog(`[PAYMENT] Verifying on-chain signature...`, 'success');
      currentStep++;
      setProgress((currentStep / totalSteps) * 100);
      await new Promise(r => setTimeout(r, 1000));

      addLog(`[SOURCE] Cloning repository...`);
      await new Promise(r => setTimeout(r, 1200));

      for (const check of checkpoints) {
        if (!mounted) break;
        addLog(`> ${check}`);
        currentStep++;
        setProgress((currentStep / totalSteps) * 100);
        
        const delay = Math.random() * 800 + 400; 
        await new Promise(r => setTimeout(r, delay));
        
        if (Math.random() > 0.85) {
             addLog(`  [WARN] Anomaly detected in heuristic scan`, 'warning');
        }
      }
      
      if (!mounted) return;
      
      addLog('[SYSTEM] Compiling final artifact...', 'info');
      currentStep++;
      setProgress(95);
      await new Promise(r => setTimeout(r, 1500));
      
      addLog('[SUCCESS] Audit complete. Hash generated.', 'success');
      setProgress(100);
      await new Promise(r => setTimeout(r, 500));
      
      onComplete();
    };

    runSimulation();

    return () => {
      mounted = false;
    };
  }, [target, type, onComplete]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  return (
    <div className="max-w-4xl mx-auto mt-10 animate-fade-in font-mono">
      <div className="mb-8 border-b-2 border-gray-800 pb-4 flex items-end justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white flex items-center gap-3 uppercase tracking-wider">
            <Loader2 className="w-8 h-8 animate-spin text-base-blue" />
            Audit in Progress
          </h2>
          <p className="text-gray-500 mt-2 text-lg">Target: <span className="text-base-blue">{target}</span></p>
        </div>
        <div className="text-right">
          <div className="text-4xl font-bold text-base-blue">{Math.round(progress)}%</div>
          <div className="text-sm text-gray-500 uppercase">Estimated Time: {Math.max(0, 30 - Math.round(progress * 0.3))}s</div>
        </div>
      </div>

      {/* Retro Progress Bar */}
      <div className="w-full bg-gray-900 border-2 border-gray-700 h-8 mb-10 p-1">
        <div 
          className="bg-base-blue h-full transition-all duration-300 ease-linear shadow-[0_0_10px_#0052FF]"
          style={{ width: `${progress}%` }}
        ></div>
      </div>

      {/* Terminal Window */}
      <div className="bg-black border-2 border-gray-700 shadow-pixel">
        <div className="bg-gray-800 px-4 py-2 flex items-center gap-2 border-b-2 border-gray-700">
          <Terminal className="w-4 h-4 text-gray-400" />
          <span className="text-gray-300 font-bold uppercase text-sm">audit_log.exe</span>
          <div className="ml-auto flex gap-2">
            <div className="w-3 h-3 bg-gray-600 hover:bg-red-500 transition-colors"></div>
            <div className="w-3 h-3 bg-gray-600 hover:bg-yellow-500 transition-colors"></div>
          </div>
        </div>
        
        <div 
          ref={scrollRef}
          className="h-[400px] overflow-y-auto p-6 space-y-2 scrollbar-hide text-lg"
        >
          {logs.map((log) => (
            <div key={log.id} className="flex items-start gap-4 animate-slide-in leading-relaxed">
              <span className="text-gray-700 select-none">
                [{new Date(log.timestamp).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute:'2-digit', second:'2-digit' })}]
              </span>
              <span className={`
                ${log.type === 'error' ? 'text-red-500 font-bold' : ''}
                ${log.type === 'warning' ? 'text-yellow-500 font-bold' : ''}
                ${log.type === 'success' ? 'text-green-500' : ''}
                ${log.type === 'info' ? 'text-gray-300' : ''}
              `}>
                {log.message}
              </span>
            </div>
          ))}
          <div className="animate-pulse text-base-blue text-xl font-bold mt-2">_</div>
        </div>
      </div>
    </div>
  );
};

export default AuditProgress;