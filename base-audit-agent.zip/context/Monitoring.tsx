import React, { useState } from 'react';
import { Activity, Clock, CheckCircle, AlertTriangle, Plus, X, Sparkles, Loader2, Lock, Crown } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import { analyzeMonitors } from '../services/geminiService';

const Monitoring: React.FC = () => {
  const { monitors, addMonitor, userTier, upgradeTier } = useAppContext();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isUpgrading, setIsUpgrading] = useState(false);
  
  // Form State
  const [name, setName] = useState('');
  const [type, setType] = useState('Mini-App');
  const [endpoint, setEndpoint] = useState('');

  const FREE_TIER_LIMIT = 2;
  const isLimitReached = userTier === 'FREE' && monitors.length >= FREE_TIER_LIMIT;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && endpoint.trim()) {
      addMonitor({
        name,
        type,
        endpoint,
      });
      // Reset & Close
      setName('');
      setType('Mini-App');
      setEndpoint('');
      setIsModalOpen(false);
    }
  };

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    setAnalysis(null);
    const result = await analyzeMonitors(monitors);
    setAnalysis(result);
    setIsAnalyzing(false);
  };

  const handleOpenModal = () => {
    if (isLimitReached) {
        return; 
    }
    setIsModalOpen(true);
  }

  const handleUpgrade = async () => {
    if (isUpgrading) return;
    setIsUpgrading(true);
    try {
        await upgradeTier();
    } catch (e: any) {
        alert(e.message || "Upgrade failed.");
    } finally {
        setIsUpgrading(false);
    }
  }

  return (
    <div className="animate-fade-in space-y-6 relative">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
          <h2 className="text-3xl font-bold text-white flex items-center gap-3">
            <Activity className="w-8 h-8 text-green-500" />
            Active Monitoring
          </h2>
          <p className="text-gray-400 mt-1">Real-time health checks for your registered Base applications.</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={handleAnalyze}
            disabled={isAnalyzing || monitors.length === 0}
            className="bg-purple-500/10 text-purple-400 border border-purple-500/20 hover:bg-purple-500/20 px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 disabled:opacity-50"
          >
            {isAnalyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            AI Analysis
          </button>
          
          {isLimitReached ? (
              <button 
                onClick={handleUpgrade}
                disabled={isUpgrading}
                className="bg-gray-800 text-gray-400 border border-gray-700 hover:bg-gray-700 px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 disabled:opacity-75"
              >
                {isUpgrading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
                {isUpgrading ? 'Upgrading...' : 'Limit Reached'}
              </button>
          ) : (
            <button 
                onClick={handleOpenModal}
                className="bg-base-blue/10 text-base-blue border border-base-blue/20 hover:bg-base-blue/20 px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
            >
                <Plus className="w-4 h-4" /> Add Monitor
            </button>
          )}
        </div>
      </div>

      {userTier === 'FREE' && (
        <div className="bg-gradient-to-r from-gray-900 to-black border border-gray-800 rounded-lg p-4 flex items-center justify-between">
            <div className="text-sm">
                <span className="text-white font-medium">Free Tier Status: </span>
                <span className="text-gray-400">{monitors.length} / {FREE_TIER_LIMIT} monitors used.</span>
            </div>
            <button onClick={handleUpgrade} disabled={isUpgrading} className="text-xs text-yellow-500 hover:text-yellow-400 flex items-center gap-1 font-bold disabled:opacity-50">
                {isUpgrading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Crown className="w-3 h-3" />}
                Upgrade for Unlimited
            </button>
        </div>
      )}

      {analysis && (
        <div className="bg-gradient-to-r from-purple-900/20 to-base-dark border border-purple-500/30 p-6 rounded-xl animate-fade-in mb-6">
           <h3 className="text-purple-300 font-bold mb-2 flex items-center gap-2">
             <Sparkles className="w-4 h-4" /> Gemini Insight
           </h3>
           <p className="text-gray-300 text-sm leading-relaxed">{analysis}</p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-gray-900 border border-gray-800 p-6 rounded-xl">
          <div className="text-gray-400 text-xs uppercase font-medium mb-2">Total Monitored</div>
          <div className="text-3xl font-bold text-white">{monitors.length}</div>
          <div className="text-xs text-green-400 mt-1">running active checks</div>
        </div>
        <div className="bg-gray-900 border border-gray-800 p-6 rounded-xl">
          <div className="text-gray-400 text-xs uppercase font-medium mb-2">Global Uptime</div>
          <div className="text-3xl font-bold text-white">99.92%</div>
          <div className="text-xs text-gray-500 mt-1">Last 30 days</div>
        </div>
        <div className="bg-gray-900 border border-gray-800 p-6 rounded-xl">
          <div className="text-gray-400 text-xs uppercase font-medium mb-2">Incidents</div>
          <div className="text-3xl font-bold text-white">0</div>
          <div className="text-xs text-gray-500 mt-1">Last 24 hours</div>
        </div>
      </div>

      <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-gray-400">
            <thead className="bg-black/20 text-xs uppercase font-medium border-b border-gray-800">
              <tr>
                <th className="px-6 py-4">Service Name</th>
                <th className="px-6 py-4">Type</th>
                <th className="px-6 py-4">Endpoint</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Uptime</th>
                <th className="px-6 py-4">Last Check</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {monitors.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-10 text-center text-gray-500 bg-gray-900/50">
                    No active monitors. Add one to get started.
                  </td>
                </tr>
              ) : (
                monitors.map((m) => (
                  <tr key={m.id} className="hover:bg-gray-800/30 transition-colors group cursor-pointer animate-slide-in">
                    <td className="px-6 py-4 font-medium text-white flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${m.status === 'Healthy' ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]' : 'bg-yellow-500 shadow-[0_0_8px_rgba(234,179,8,0.6)]'}`}></div>
                      {m.name}
                    </td>
                    <td className="px-6 py-4">
                      <span className="bg-gray-800 text-gray-300 px-2 py-1 rounded text-xs border border-gray-700">
                        {m.type}
                      </span>
                    </td>
                    <td className="px-6 py-4 font-mono text-xs text-gray-500 group-hover:text-base-blue transition-colors">
                      {m.endpoint}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${
                        m.status === 'Healthy' 
                          ? 'bg-green-500/10 text-green-400 border-green-500/20' 
                          : 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
                      }`}>
                        {m.status === 'Healthy' ? <CheckCircle className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                        {m.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 font-mono">{m.uptime}</td>
                    <td className="px-6 py-4 flex items-center gap-2 text-gray-500">
                      <Clock className="w-3 h-3" />
                      {m.lastCheck}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Monitor Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
           <div className="bg-gray-900 border border-gray-800 rounded-xl w-full max-w-md shadow-2xl overflow-hidden">
              <div className="flex justify-between items-center p-6 border-b border-gray-800">
                 <h3 className="text-xl font-bold text-white">Add New Monitor</h3>
                 <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-white">
                    <X className="w-5 h-5" />
                 </button>
              </div>
              <form onSubmit={handleSubmit} className="p-6 space-y-4">
                 <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Service Name</label>
                    <input 
                      type="text" 
                      value={name}
                      onChange={e => setName(e.target.value)}
                      placeholder="e.g. Production API" 
                      className="w-full bg-black border border-gray-800 rounded-lg py-2 px-4 text-white focus:border-base-blue focus:outline-none"
                      required
                    />
                 </div>
                 <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Type</label>
                    <select 
                      value={type}
                      onChange={e => setType(e.target.value)}
                      className="w-full bg-black border border-gray-800 rounded-lg py-2 px-4 text-white focus:border-base-blue focus:outline-none"
                    >
                       <option>Mini-App</option>
                       <option>AI Agent</option>
                       <option>Smart Contract</option>
                    </select>
                 </div>
                 <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Endpoint / Address</label>
                    <input 
                      type="text" 
                      value={endpoint}
                      onChange={e => setEndpoint(e.target.value)}
                      placeholder="https://... or 0x..." 
                      className="w-full bg-black border border-gray-800 rounded-lg py-2 px-4 text-white focus:border-base-blue focus:outline-none"
                      required
                    />
                 </div>
                 <div className="pt-4 flex gap-3">
                    <button 
                      type="button" 
                      onClick={() => setIsModalOpen(false)}
                      className="flex-1 py-2.5 bg-gray-800 text-gray-300 rounded-lg hover:bg-gray-700 font-medium"
                    >
                      Cancel
                    </button>
                    <button 
                      type="submit"
                      className="flex-1 py-2.5 bg-base-blue text-white rounded-lg hover:bg-blue-600 font-medium"
                    >
                      Create Monitor
                    </button>
                 </div>
              </form>
           </div>
        </div>
      )}
    </div>
  );
};

export default Monitoring;