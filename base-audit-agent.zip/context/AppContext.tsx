import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { Monitor, ApiKey, UserTier } from '../types';
import { BASE_CHAIN_ID, BASE_RPC_URL, BASE_EXPLORER_URL } from '../constants';
import { payUSDC } from '../services/paymentService';

interface AppContextType {
  walletAddress: string | null;
  isConnecting: boolean;
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  monitors: Monitor[];
  addMonitor: (monitor: Omit<Monitor, 'id' | 'status' | 'uptime' | 'lastCheck'>) => void;
  apiKeys: ApiKey[];
  generateApiKey: () => void;
  revokeApiKey: (id: string) => void;
  userTier: UserTier;
  upgradeTier: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [userTier, setUserTier] = useState<UserTier>('FREE');
  
  const DEFAULT_MONITORS: Monitor[] = [
    { id: 1, name: 'DeFi Swap Protocol', type: 'Mini-App', status: 'Healthy', uptime: '99.9%', lastCheck: '2s ago', endpoint: 'api.base-swap.org' },
    { id: 4, name: 'NFT Minting API', type: 'Mini-App', status: 'Healthy', uptime: '99.8%', lastCheck: '1s ago', endpoint: 'mint.base.org' },
  ];

  const [monitors, setMonitors] = useState<Monitor[]>(DEFAULT_MONITORS);
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);

  // Initialize wallet listeners and check existing connection
  useEffect(() => {
    const ethereum = (window as any).ethereum;
    if (ethereum) {
      // 1. Check if already connected (Reconnection logic)
      ethereum.request({ method: 'eth_accounts' })
        .then((accounts: string[]) => {
          if (accounts.length > 0) {
            setWalletAddress(accounts[0]);
          }
        })
        .catch((err: any) => console.error("Failed to check existing connection:", err));

      // 2. Listen for account changes
      const handleAccountsChanged = (accounts: string[]) => {
        if (accounts.length > 0) {
          setWalletAddress(accounts[0]);
        } else {
          disconnectWallet(); // Ensure clean disconnect if locked from wallet
        }
      };

      // 3. Listen for chain changes
      const handleChainChanged = (_chainId: string) => {
        console.log("Network changed to:", _chainId);
      };

      ethereum.on('accountsChanged', handleAccountsChanged);
      ethereum.on('chainChanged', handleChainChanged);

      return () => {
        if (ethereum.removeListener) {
            ethereum.removeListener('accountsChanged', handleAccountsChanged);
            ethereum.removeListener('chainChanged', handleChainChanged);
        }
      };
    }
  }, []);

  const connectWallet = async () => {
    const ethereum = (window as any).ethereum;
    if (!ethereum) {
        alert("No crypto wallet found. Please install Coinbase Wallet or MetaMask.");
        return;
    }

    if (isConnecting) return;
    setIsConnecting(true);

    try {
      // Request accounts
      const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
      if (accounts.length > 0) {
          setWalletAddress(accounts[0]);
          
          // Force switch to Base
          try {
            await ethereum.request({
              method: 'wallet_switchEthereumChain',
              params: [{ chainId: BASE_CHAIN_ID }],
            });
          } catch (switchError: any) {
            // This error code indicates that the chain has not been added to MetaMask.
            if (switchError.code === 4902) {
              try {
                await ethereum.request({
                    method: 'wallet_addEthereumChain',
                    params: [{
                        chainId: BASE_CHAIN_ID,
                        chainName: 'Base Mainnet',
                        nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
                        rpcUrls: [BASE_RPC_URL],
                        blockExplorerUrls: [BASE_EXPLORER_URL],
                    }],
                });
              } catch (addError) {
                console.error("Failed to add Base network:", addError);
              }
            } else {
              console.error("Failed to switch network:", switchError);
            }
          }
      }
    } catch (e: any) {
      console.error("Connection failed or rejected", e);
      if (e.code === 4001) {
          // User rejected
      } else {
          alert("Failed to connect wallet.");
      }
    } finally {
      setIsConnecting(false);
    }
  };

  const disconnectWallet = () => {
    setWalletAddress(null);
    // Reset state to default on disconnect
    setUserTier('FREE');
    setApiKeys([]);
    setMonitors(DEFAULT_MONITORS);
  };

  const addMonitor = (data: Omit<Monitor, 'id' | 'status' | 'uptime' | 'lastCheck'>) => {
    const newMonitor: Monitor = {
      id: Date.now(),
      ...data,
      status: 'Healthy',
      uptime: '100%',
      lastCheck: 'Just now'
    };
    setMonitors(prev => [...prev, newMonitor]);
  };

  const generateApiKey = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let randomStr = '';
    for (let i = 0; i < 24; i++) {
        randomStr += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    const newKey: ApiKey = {
      id: Date.now().toString(),
      key: `pk_live_${randomStr}`,
      created: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      lastUsed: 'Never'
    };
    setApiKeys(prev => [...prev, newKey]);
  };

  const revokeApiKey = (id: string) => {
    setApiKeys(prev => prev.filter(k => k.id !== id));
  };

  const upgradeTier = async () => {
    if (!walletAddress) {
      // Try to connect if not connected
      try {
        await connectWallet();
        // If still not connected after attempt, throw error
        const ethereum = (window as any).ethereum;
        const accounts = await ethereum.request({ method: 'eth_accounts' });
        if (!accounts || accounts.length === 0) {
           throw new Error("Please connect your wallet to upgrade.");
        }
      } catch (e) {
        throw new Error("Please connect your wallet to upgrade.");
      }
    }

    try {
      // Charge $9.99 USDC
      await payUSDC("9.99");
      setUserTier('PREMIUM');
    } catch (error) {
      console.error("Upgrade payment failed:", error);
      throw error;
    }
  };

  return (
    <AppContext.Provider value={{
      walletAddress,
      isConnecting,
      connectWallet,
      disconnectWallet,
      monitors,
      addMonitor,
      apiKeys,
      generateApiKey,
      revokeApiKey,
      userTier,
      upgradeTier
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};