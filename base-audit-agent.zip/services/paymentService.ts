import { TREASURY_WALLET, BASE_CHAIN_ID, BASE_RPC_URL, BASE_EXPLORER_URL } from '../constants';

const USDC_ADDRESS = '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913';

export const payUSDC = async (amountStr: string): Promise<string> => {
  // Check for window.ethereum
  if (typeof window === 'undefined' || !(window as any).ethereum) {
     throw new Error("No crypto wallet found. Please install a wallet like Coinbase Wallet or MetaMask.");
  }
  
  const ethereum = (window as any).ethereum;

  // 1. Request Access / Check Connection
  const accounts = await ethereum.request({ method: 'eth_requestAccounts' }).catch((err: any) => {
    if (err.code === 4001) throw new Error("Wallet connection rejected by user.");
    throw new Error("Failed to connect wallet.");
  });
  
  if (!accounts || accounts.length === 0) {
    throw new Error("No accounts found. Please unlock your wallet.");
  }
  const account = accounts[0];

  // 2. Switch to Base Chain
  try {
    const currentChainId = await ethereum.request({ method: 'eth_chainId' });
    if (currentChainId !== BASE_CHAIN_ID) {
      await ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: BASE_CHAIN_ID }],
      });
    }
  } catch (switchError: any) {
    // 4902 means chain not added
    if (switchError.code === 4902) {
       try {
        await ethereum.request({
          method: 'wallet_addEthereumChain',
          params: [{
            chainId: BASE_CHAIN_ID,
            chainName: 'Base Mainnet',
            nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
            rpcUrls: [BASE_RPC_URL],
            blockExplorerUrls: [BASE_EXPLORER_URL],
          }],
        });
       } catch (addError) {
         throw new Error("Could not add Base network to wallet. Please add it manually.");
       }
    } else {
      throw new Error("Failed to switch to Base network. Please switch manually.");
    }
  }

  // 3. Build Transaction
  // USDC on Base has 6 decimals
  const amount = parseFloat(amountStr);
  const amountBigInt = BigInt(Math.floor(amount * 1_000_000));
  const amountHex = amountBigInt.toString(16).padStart(64, '0');
  
  const cleanAddress = TREASURY_WALLET.replace('0x', '');
  const toAddressPad = cleanAddress.padStart(64, '0');
  
  // ERC-20 transfer(address,uint256) selector: a9059cbb
  const data = `0xa9059cbb${toAddressPad}${amountHex}`;

  try {
    const txHash = await ethereum.request({
      method: 'eth_sendTransaction',
      params: [
        {
          from: account,
          to: USDC_ADDRESS,
          data: data,
          value: '0x0', // 0 ETH value, only ERC20 transfer
        },
      ],
    });
    return txHash;
  } catch (err: any) {
    console.error(err);
    if (err.code === 4001) {
        throw new Error("Transaction rejected by user.");
    }
    throw new Error("Transaction failed. Please try again.");
  }
};