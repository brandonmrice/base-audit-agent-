import { GoogleGenAI, Type } from "@google/genai";
import { AuditResult, AuditType, Severity, Monitor } from "../types";

const GEMINI_API_KEY = process.env.API_KEY || '';

export interface AuditErrorDetails {
  code: string;
  message: string;
  attempts?: number;
  originalError?: any;
  suggestion?: string;
}

export class AuditServiceError extends Error {
  constructor(public details: AuditErrorDetails) {
    super(details.message);
    this.name = 'AuditServiceError';
  }
}

// Fallback if no API key is present (for demo purposes if env not set)
const MOCK_RESPONSE: AuditResult = {
  id: 'mock-123',
  target: 'demo-target',
  type: AuditType.MINI_APP,
  totalScore: 85,
  timestamp: new Date().toISOString(),
  summary: "This is a mock audit result because no API key was provided. The application is generally secure but has some minor performance issues.",
  categories: [
    {
      name: "Security",
      score: 90,
      maxScore: 100,
      issues: []
    },
    {
      name: "Performance",
      score: 75,
      maxScore: 100,
      issues: [
        {
          severity: Severity.MEDIUM,
          title: "Large Bundle Size",
          description: "Main bundle exceeds 2MB.",
          remediation: "Implement code splitting.",
          vulnerabilityType: "Performance",
          codeSnippet: "npm run build --analyze"
        }
      ]
    },
    {
      name: "Onchain Integration",
      score: 95,
      maxScore: 100,
      issues: []
    }
  ]
};

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

async function retryOperation<T>(
  operation: () => Promise<T>,
  maxRetries: number = 3,
  baseDelay: number = 1000
): Promise<T> {
  let lastError: any;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await operation();
    } catch (error: any) {
      lastError = error;
      const waitTime = baseDelay * Math.pow(2, attempt);
      console.warn(`Attempt ${attempt + 1} failed. Retrying in ${waitTime}ms...`, error.message);
      
      // Don't retry if it's a client error (e.g. invalid API key)
      if (error.message?.includes('API_KEY_INVALID') || error.status === 400 || error.status === 401) {
        throw new AuditServiceError({
           code: 'CLIENT_ERROR',
           message: 'Invalid API Key or Bad Request. Please check your configuration.',
           suggestion: 'Go to Settings and generate a new API Key.',
           attempts: attempt + 1,
           originalError: error
        });
      }

      if (attempt < maxRetries - 1) {
        await delay(waitTime);
      }
    }
  }

  throw new AuditServiceError({
    code: 'MAX_RETRIES_EXCEEDED',
    message: `Operation failed after ${maxRetries} attempts. Service may be unavailable.`,
    suggestion: 'Please try again in a few minutes or check your internet connection.',
    attempts: maxRetries,
    originalError: lastError
  });
}

export const generateAuditReport = async (target: string, type: AuditType): Promise<AuditResult> => {
  // 1. Mock Mode Check
  if (!GEMINI_API_KEY) {
    console.warn("No Gemini API Key found. Returning mock data.");
    await delay(1500); // Simulate network latency
    return { ...MOCK_RESPONSE, target, type, id: crypto.randomUUID() };
  }

  // 2. Initialize Gemini
  const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });

  const specificInstructions = {
    [AuditType.MINI_APP]: `
      - Vulnerability Check: CORS Misconfigurations (e.g., 'Access-Control-Allow-Origin: *' on sensitive endpoints).
      - Vulnerability Check: Exposed secrets or private keys in client-side bundles (Scan for "pk_live", "sk_test").
      - Base Check: OnchainKit Provider configuration, Manifest.json validity, and correct Chain ID (8453).
      - Vulnerability Check: Wallet connection persistence (ensure graceful handling of disconnects/reloads via Wagmi/RainbowKit).
      - Base Check: Farcaster Frame signature validation (verify 'trustedData.messageBytes' to prevent spoofing).
      - Performance: RPC URL failover configuration (avoiding single points of failure with public Base RPCs).
      - Security: Input sanitation for transaction arguments to prevent UI-level parameter tampering.
      - UX: Hardcoded gas limit checks (ensure dynamic estimation is used for L2 cost variance).
    `,
    [AuditType.AI_AGENT]: `
      - Vulnerability Check: Prompt Injection risks (leaking system instructions via adversarial inputs).
      - Vulnerability Check: Uncapped transaction signing limits or missing spending allowances in CDP AgentKit.
      - Base Check: Wallet funding verification and autonomy safeguards for on-chain actions.
      - Security: Private key storage hygiene (flagging use of plain text environment variables vs secure enclaves/MPC).
      - Logic Check: Hallucination safeguards for transaction data (verify function selectors match user intent).
      - Risk: Infinite approval exploits (Agent granting max uint256 allowance to untrusted protocols).
      - Security: Denial of Wallet (DoW) protection (preventing fund draining via loop-based commands).
      - Base Check: Context window overflow resilience (ensuring system prompts regarding gas limits persist).
    `,
    [AuditType.SMART_CONTRACT]: `
      - Vulnerability Check: Reentrancy vulnerabilities (Check-Effects-Interactions pattern violations).
      - Vulnerability Check: AccessControl flaws (unprotected sensitive functions like 'onlyOwner').
      - Base Check: Gas optimization for L2 execution (calldata vs memory), storage layout, and proxy upgrade safety.
      - Vulnerability Check: Unchecked external call return values (handling failures in low-level 'call').
      - Base Check: L2 Block timestamp manipulation risks (validating logic against Optimism stack block time characteristics).
      - Security: 'tx.origin' usage for authorization (preventing phishing-based access bypass).
      - Performance: Event emission optimization (avoiding excessive indexing costs on Base graph nodes).
      - Logic Check: Integer overflow/underflow in unchecked assembly blocks.
    `
  };

  const prompt = `
    You are the 'Base Audit Agent', a specialized security auditor for the Base Blockchain ecosystem using the 142-checkpoint framework.
    
    Target: "${target}"
    Type: "${type}"
    
    Perform a comprehensive, simulated technical audit.
    If the target is a generic placeholder, generate realistic, educational findings relevant to the type.
    
    MANDATORY CHECKS:
    ${specificInstructions[type]}
    
    Return the data strictly in JSON format matching the schema. 
    Ensure 'vulnerabilityType' categorizes the issue (e.g., "Smart Contract", "Network", "Logic", "Auth").
    If applicable, provide a short 'codeSnippet' demonstrating the flaw or fix.
  `;

  // 3. Execute with Retry
  return retryOperation(async () => {
    let response;
    try {
        response = await ai.models.generateContent({
          model: "gemini-2.5-flash",
          contents: prompt,
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                totalScore: { type: Type.INTEGER, description: "Overall score 0-100" },
                summary: { type: Type.STRING, description: "Executive summary of findings" },
                categories: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      name: { type: Type.STRING },
                      score: { type: Type.INTEGER },
                      maxScore: { type: Type.INTEGER },
                      issues: {
                        type: Type.ARRAY,
                        items: {
                          type: Type.OBJECT,
                          properties: {
                            severity: { type: Type.STRING, enum: ["CRITICAL", "HIGH", "MEDIUM", "LOW"] },
                            title: { type: Type.STRING },
                            description: { type: Type.STRING },
                            remediation: { type: Type.STRING },
                            vulnerabilityType: { type: Type.STRING, description: "Category of vulnerability" },
                            codeSnippet: { type: Type.STRING, description: "Optional code snippet showing issue or fix" }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        });
    } catch (apiError: any) {
        throw new Error(`Gemini API Request Failed: ${apiError.message}`);
    }

    const text = response.text;
    if (!text) {
        throw new Error("Empty response received from Gemini API");
    }

    let data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      throw new Error("Failed to parse JSON response from Gemini");
    }

    return {
      id: crypto.randomUUID(),
      target,
      type,
      timestamp: new Date().toISOString(),
      ...data
    };
  });
};

export const analyzeMonitors = async (monitors: Monitor[]): Promise<string> => {
  if (!GEMINI_API_KEY) {
    await delay(1000);
    return "Mock Analysis: Your systems appear healthy, though 'Treasury Agent Alpha' is showing intermittent latency warnings. Consider increasing the timeout threshold.";
  }

  const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });
  const monitorData = JSON.stringify(monitors);
  const prompt = `
    Analyze the following system monitor data for a Base blockchain application ecosystem. 
    Provide a concise, technical summary of the overall health, identifying any patterns or specific services that need attention.
    Suggest 1 actionable improvement.
    Data: ${monitorData}
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });
    return response.text || "No analysis generated.";
  } catch (e) {
    console.error(e);
    return "Failed to generate AI analysis. Please try again.";
  }
};